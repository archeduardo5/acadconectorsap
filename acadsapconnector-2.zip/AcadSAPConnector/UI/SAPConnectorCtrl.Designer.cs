﻿namespace AcadSAPConnector
{
    partial class SAPConnectorCtrl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.bProps = new System.Windows.Forms.Button();
            this.panelTable = new System.Windows.Forms.Panel();
            this._propsTableCtrl = new AcadSAPConnector.PropertiesTableCtrl();
            this._filterCtrl = new AcadSAPConnector.FilterCtrl();
            this.panelTop.SuspendLayout();
            this.panelTable.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this._filterCtrl);
            this.panelTop.Controls.Add(this.bProps);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(717, 110);
            this.panelTop.TabIndex = 0;
            // 
            // bProps
            // 
            this.bProps.Location = new System.Drawing.Point(12, 28);
            this.bProps.Name = "bProps";
            this.bProps.Size = new System.Drawing.Size(93, 39);
            this.bProps.TabIndex = 2;
            this.bProps.Text = "Select Properties...";
            this.bProps.UseVisualStyleBackColor = true;
            this.bProps.Click += new System.EventHandler(this.bProps_Click);
            // 
            // panelTable
            // 
            this.panelTable.Controls.Add(this._propsTableCtrl);
            this.panelTable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTable.Location = new System.Drawing.Point(0, 110);
            this.panelTable.Name = "panelTable";
            this.panelTable.Size = new System.Drawing.Size(717, 405);
            this.panelTable.TabIndex = 1;
            // 
            // _propsTableCtrl
            // 
            this._propsTableCtrl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._propsTableCtrl.Location = new System.Drawing.Point(0, 0);
            this._propsTableCtrl.Name = "_propsTableCtrl";
            this._propsTableCtrl.Size = new System.Drawing.Size(717, 405);
            this._propsTableCtrl.TabIndex = 0;
            // 
            // _filterCtrl
            // 
            this._filterCtrl.Location = new System.Drawing.Point(111, 12);
            this._filterCtrl.Name = "_filterCtrl";
            this._filterCtrl.Size = new System.Drawing.Size(590, 74);
            this._filterCtrl.TabIndex = 3;
            // 
            // SAPConnectorCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelTable);
            this.Controls.Add(this.panelTop);
            this.Name = "SAPConnectorCtrl";
            this.Size = new System.Drawing.Size(717, 515);
            this.panelTop.ResumeLayout(false);
            this.panelTable.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Button bProps;
        private System.Windows.Forms.Panel panelTable;
        private AcadSAPConnector.FilterCtrl _filterCtrl;
        private AcadSAPConnector.PropertiesTableCtrl _propsTableCtrl;

    }
}
