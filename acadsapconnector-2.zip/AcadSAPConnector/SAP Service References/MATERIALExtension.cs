using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SAP.Gwdt.Framework;

namespace MATERIAL
{
		
	public partial class MATERIAL
    {
		/// <summary>
        /// This Property must be set in order to connect to a service that doesn't use the default sap client
        /// </summary>
        public string SapClient { get; set; }

		/// <summary>
        ///     Constructor of Entity Container that also receives sap client
        /// </summary>
        /// <param name="serviceRoot">The service root uri</param>
        /// <param name="sapClient">The sap client of the service</param>
        public MATERIAL(Uri serviceRoot, string sapClient) : this(serviceRoot)
        {
            this.SapClient = sapClient;
        }

		/// <summary>
        ///     This method is invoked each time the entity container is created.
        ///     Use this method to add event handler to each call to the service
        partial void OnContextCreated()
        {
            this.SendingRequest += new EventHandler<System.Data.Services.Client.SendingRequestEventArgs>(MATERIAL_SendingRequest);
        }

		/// <summary>
        ///     The event handler of this entity container which occurs on each
        ///     Request sent to the serivce. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void MATERIAL_SendingRequest(object sender, System.Data.Services.Client.SendingRequestEventArgs e)
        {
			ProxyHelper.AddSapHttpHeaders(e, this.SapClient);
        }
    }

	}
