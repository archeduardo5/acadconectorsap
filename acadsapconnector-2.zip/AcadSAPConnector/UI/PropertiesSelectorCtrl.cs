﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;


namespace AcadSAPConnector
{
    public partial class PropertiesSelectorCtrl : UserControl
    {
        public PropertiesSelectorCtrl()
        {
            InitializeComponent();

            _tvProps.AfterCheck += new TreeViewEventHandler(AfterCheck);
        }

        void AfterCheck(object sender, TreeViewEventArgs e)
        {
            foreach (TreeNode node in e.Node.Nodes)
            {
                node.Checked = e.Node.Checked;
            }
        }

        public void LoadProperties(
            Type type,
            string[] currentProperties)
        {
            _tvProps.Nodes.Clear();

            TreeNode rootNode = _tvProps.Nodes.Add(type.Name);

            foreach (MemberInfo memberInfo in type.GetMembers())
            {
                if (memberInfo.DeclaringType == type)
                { 
                    if(memberInfo.MemberType == MemberTypes.Property)
                    {
                        TreeNode node = rootNode.Nodes.Add(memberInfo.Name);

                        if(currentProperties.Contains(memberInfo.Name))
                            node.Checked = true;
                    }
                }
            }

            rootNode.ExpandAll();
        }

        public string[] SelectedProperties
        {
            get
            {
                List<string> props = new List<string>();

                TreeNode rootNode = _tvProps.Nodes[0];

                foreach (TreeNode node in rootNode.Nodes)
                {
                    if (node.Checked)
                        props.Add(node.Text);
                }

                return props.ToArray();
            }
        }
    }
}
