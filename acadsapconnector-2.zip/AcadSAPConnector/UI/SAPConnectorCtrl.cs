﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AcadSAPConnector
{
    public partial class SAPConnectorCtrl : UserControl
    {
        SapConnector _sapConnector;

        string[] _currentproperties = new string[] 
        {
            "MaterialDescription",
            "CreatedBy",
            "CreatedOn"
        };

        public SAPConnectorCtrl()
        {
            InitializeComponent();

            _sapConnector = new SapConnector();

            _filterCtrl.FilterModifiedEvent +=
                new FilterModifiedHandler(FilterModifiedEvent);
        }

        public void RefreshContent()
        {
            _propsTableCtrl.ClearItems();

            _sapConnector.InitializeSAP();
            
            var materials = _sapConnector.GetMaterials(50);

            if(materials == null)
            {
                System.Windows.Forms.MessageBox.Show(
                    "Unable to connect SAP Gateway"
                    + Environment.NewLine
                    + "Check your Internet connection...",
                    "SAP Gateway Error");

                return;
            }

            foreach (MATERIAL.Material material in materials)
            {
                _propsTableCtrl.AddItem(material);
            }

            _propsTableCtrl.LoadProperties(_currentproperties);
        }

        void FilterModifiedEvent(object o, FilterModifiedEventArgs e)
        {
            _propsTableCtrl.ClearItems();

            if (!e.Enabled)
            {
                RefreshContent();
            }
            else
            {
                var materials = _sapConnector.FilterMaterials(
                    50, 
                    e.Expression, 
                    e.Contains);

                if (materials == null)
                {
                    System.Windows.Forms.MessageBox.Show(
                        "Unable to connect SAP Gateway"
                        + Environment.NewLine
                        + "Check your Internet connection...",
                        "SAP Gateway Error");

                    return;
                }

                foreach (MATERIAL.Material material in materials)
                {
                    _propsTableCtrl.AddItem(material);
                }

                _propsTableCtrl.LoadProperties(
                    _currentproperties);
            }
        }

        private void bProps_Click(object sender, EventArgs e)
        {
            PropertiesSelectorForm propSelector =
               new PropertiesSelectorForm(
                   typeof(MATERIAL.Material),
                   _currentproperties);

            propSelector.ShowDialog();

            _currentproperties = propSelector.SelectedProperties;

            _propsTableCtrl.LoadProperties(_currentproperties);
        }
    }
}
