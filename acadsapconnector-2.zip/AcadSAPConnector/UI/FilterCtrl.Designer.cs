﻿namespace AcadSAPConnector
{
    partial class FilterCtrl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbFilter = new System.Windows.Forms.GroupBox();
            this.bRefresh = new System.Windows.Forms.Button();
            this._cbMode = new System.Windows.Forms.ComboBox();
            this._cbProps = new System.Windows.Forms.ComboBox();
            this._tbValue = new System.Windows.Forms.TextBox();
            this._cbFilter = new System.Windows.Forms.CheckBox();
            this.gbFilter.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbFilter
            // 
            this.gbFilter.Controls.Add(this.bRefresh);
            this.gbFilter.Controls.Add(this._cbMode);
            this.gbFilter.Controls.Add(this._cbProps);
            this.gbFilter.Controls.Add(this._tbValue);
            this.gbFilter.Controls.Add(this._cbFilter);
            this.gbFilter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbFilter.Location = new System.Drawing.Point(0, 0);
            this.gbFilter.Name = "gbFilter";
            this.gbFilter.Size = new System.Drawing.Size(590, 74);
            this.gbFilter.TabIndex = 7;
            this.gbFilter.TabStop = false;
            this.gbFilter.Text = "Filter";
            // 
            // bRefresh
            // 
            this.bRefresh.Location = new System.Drawing.Point(522, 42);
            this.bRefresh.Name = "bRefresh";
            this.bRefresh.Size = new System.Drawing.Size(62, 21);
            this.bRefresh.TabIndex = 9;
            this.bRefresh.Text = "Refresh";
            this.bRefresh.UseVisualStyleBackColor = true;
            this.bRefresh.Click += new System.EventHandler(this.bGo_Click);
            // 
            // _cbMode
            // 
            this._cbMode.FormattingEnabled = true;
            this._cbMode.Items.AddRange(new object[] {
            "equal",
            "does not equal"});
            this._cbMode.Location = new System.Drawing.Point(220, 42);
            this._cbMode.Name = "_cbMode";
            this._cbMode.Size = new System.Drawing.Size(127, 21);
            this._cbMode.TabIndex = 8;
            // 
            // _cbProps
            // 
            this._cbProps.FormattingEnabled = true;
            this._cbProps.Items.AddRange(new object[] {
            "Material Description"});
            this._cbProps.Location = new System.Drawing.Point(6, 42);
            this._cbProps.Name = "_cbProps";
            this._cbProps.Size = new System.Drawing.Size(208, 21);
            this._cbProps.TabIndex = 7;
            // 
            // _tbValue
            // 
            this._tbValue.Location = new System.Drawing.Point(353, 42);
            this._tbValue.Name = "_tbValue";
            this._tbValue.Size = new System.Drawing.Size(163, 20);
            this._tbValue.TabIndex = 6;
            this._tbValue.TextChanged += new System.EventHandler(this.tbValue_TextChanged);
            // 
            // _cbFilter
            // 
            this._cbFilter.AutoSize = true;
            this._cbFilter.Location = new System.Drawing.Point(6, 19);
            this._cbFilter.Name = "_cbFilter";
            this._cbFilter.Size = new System.Drawing.Size(84, 17);
            this._cbFilter.TabIndex = 5;
            this._cbFilter.Text = "Enable Filter";
            this._cbFilter.UseVisualStyleBackColor = true;
            this._cbFilter.CheckedChanged += new System.EventHandler(this.cbFilter_CheckedChanged);
            // 
            // FilterCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gbFilter);
            this.Name = "FilterCtrl";
            this.Size = new System.Drawing.Size(590, 74);
            this.gbFilter.ResumeLayout(false);
            this.gbFilter.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbFilter;
        private System.Windows.Forms.ComboBox _cbMode;
        private System.Windows.Forms.ComboBox _cbProps;
        private System.Windows.Forms.TextBox _tbValue;
        private System.Windows.Forms.CheckBox _cbFilter;
        private System.Windows.Forms.Button bRefresh;
    }
}
