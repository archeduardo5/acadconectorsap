﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AcadSAPConnector
{
    public partial class PropertiesSelectorForm : Form
    {
        public PropertiesSelectorForm(Type type, string[] currentProperties)
        {
            InitializeComponent();

            _propsSelectorCtrl.LoadProperties(
                type,
                currentProperties);
        }

        public string[] SelectedProperties
        {
            get
            {
                return _propsSelectorCtrl.SelectedProperties;
            }
        }
    }
}
