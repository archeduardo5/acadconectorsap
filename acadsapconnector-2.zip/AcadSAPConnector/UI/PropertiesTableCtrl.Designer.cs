﻿namespace AcadSAPConnector
{
    partial class PropertiesTableCtrl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "item1",
            "sub1"}, -1);
            this.panelDown = new System.Windows.Forms.Panel();
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelMain = new System.Windows.Forms.Panel();
            this._lvProps = new ListViewEmbeddedControls.AdnListViewEx();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panelMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelDown
            // 
            this.panelDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDown.Location = new System.Drawing.Point(0, 327);
            this.panelDown.Name = "panelDown";
            this.panelDown.Size = new System.Drawing.Size(423, 48);
            this.panelDown.TabIndex = 0;
            this.panelDown.Visible = false;
            // 
            // panelTop
            // 
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(423, 41);
            this.panelTop.TabIndex = 1;
            this.panelTop.Visible = false;
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this._lvProps);
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Location = new System.Drawing.Point(0, 41);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(423, 286);
            this.panelMain.TabIndex = 2;
            // 
            // _lvProps
            // 
            this._lvProps.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this._lvProps.Dock = System.Windows.Forms.DockStyle.Fill;
            this._lvProps.EnableAutoResize = true;
            this._lvProps.GridLines = true;
            this._lvProps.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
            this._lvProps.Location = new System.Drawing.Point(0, 0);
            this._lvProps.Name = "_lvProps";
            this._lvProps.ShowGroups = false;
            this._lvProps.Size = new System.Drawing.Size(423, 286);
            this._lvProps.TabIndex = 0;
            this._lvProps.UseCompatibleStateImageBehavior = false;
            this._lvProps.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 419;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Width = 82;
            // 
            // PropertiesTableCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelMain);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelDown);
            this.Name = "PropertiesTableCtrl";
            this.Size = new System.Drawing.Size(423, 375);
            this.panelMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelDown;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelMain;
        private ListViewEmbeddedControls.AdnListViewEx _lvProps;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
    }
}
