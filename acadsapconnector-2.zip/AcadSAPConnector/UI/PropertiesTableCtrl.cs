﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace AcadSAPConnector
{
    public partial class PropertiesTableCtrl : UserControl
    {
        List<object> _items;

        public PropertiesTableCtrl()
        {
            InitializeComponent();

            _items = new List<object>();
        }

        private string GetPropValue(object obj, string propName)
        {
            try
            {
                object res = obj.GetType().InvokeMember(
                    propName,
                    System.Reflection.BindingFlags.GetProperty,
                    null,
                    obj,
                    null,
                    null, null, null);

                string strRes = res.ToString();

                return (strRes == "" ? "*Undefined*" : strRes);
            }
            catch
            {
                return "*Invalid*";
            }
        }

        public void AddItem(object obj)
        {
            _items.Add(obj);
        }

        public void ClearItems()
        {
            _items.Clear();

            _lvProps.Items.Clear();

            _lvProps.Columns.Clear();
        }

        public void LoadProperties(string[] properties)
        {
            _lvProps.Columns.Clear();

            _lvProps.Items.Clear();

            _lvProps.Columns.Add("Item Number");

            foreach (string propName in properties)
            {
                _lvProps.Columns.Add(propName);
            }

            foreach (object obj in _items)
            {
                ListViewItem lvitem = _lvProps.Items.Insert(
                    _lvProps.Items.Count,
                    "Item " + (_lvProps.Items.Count+1).ToString());

                foreach (string propName in properties)
                {
                    string value = GetPropValue(obj, propName);

                    lvitem.SubItems.Add(value);
                }
            }
        }
    }
}
