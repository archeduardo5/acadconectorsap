using System;
using System.Collections.Generic;
using System.Linq;
using SAP.Gwdt.Framework;

namespace MATERIAL
{
	public partial class MATERIAL
    {
		static Dictionary<string, EntitySetMetadata> sapEntitySetAttributes = new Dictionary<string, EntitySetMetadata>() { 
					{"MaterialCollection", new EntitySetMetadata() { deletable = "false", creatable = "false", updatable = "false", queryable = "" }}  ,
			          			{"AlternativeUOMCollection", new EntitySetMetadata() { deletable = "false", creatable = "false", updatable = "false", queryable = "" }}           		  
		};
		
        public static Dictionary<string, EntitySetMetadata> SAPEntitySetAttributes
        {
            get
            {
                return sapEntitySetAttributes;
            }
        }

    }

    public partial class Material
    {
        static Dictionary<string, PropertyMetadata> sapPropertyAttributes = new Dictionary<string, PropertyMetadata>() { 
					{"MaterialDescription", new PropertyMetadata() { label = "Material Description", creatable = "false", updatable = "false", filterable = "", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"CreatedOn", new PropertyMetadata() { label = "Created On (Date/Time in UTC)", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"SalesOrganization", new PropertyMetadata() { label = "Sales Organization", creatable = "false", updatable = "false", filterable = "", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"SizeDimensions", new PropertyMetadata() { label = "Size/dimensions", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"Plant", new PropertyMetadata() { label = "Plant", creatable = "false", updatable = "false", filterable = "", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"ProductHierarchy", new PropertyMetadata() { label = "Product Hierarchy", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"LabelType", new PropertyMetadata() { label = "Label Type", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"CreatedBy", new PropertyMetadata() { label = "Created By", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"NetWeight", new PropertyMetadata() { label = "Net Weight", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"DimensionUnit", new PropertyMetadata() { label = "Dimension Unit", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"PurchasingValueKey", new PropertyMetadata() { label = "Purchasing Value Key", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"BaseUOM", new PropertyMetadata() { label = "Base Unit of Measure", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"Volume", new PropertyMetadata() { label = "Volume", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"PlantDeletionFlag", new PropertyMetadata() { label = "Plant Deletion Flag", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"Width", new PropertyMetadata() { label = "Width", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"ChangedBy", new PropertyMetadata() { label = "Changed By", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"MaterialGroup", new PropertyMetadata() { label = "Material Group", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"ChangedOn", new PropertyMetadata() { label = "Changed On  (Date/Time in UTC)", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"BaseUOMDescription", new PropertyMetadata() { label = "Base Unit of Measure", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"MaterialType", new PropertyMetadata() { label = "Material Type", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"VolumeUnitInISO", new PropertyMetadata() { label = "Volume Unit ISO", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"WeightUnitDescription", new PropertyMetadata() { label = "Weight Unit", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"PurchaseOrderUnit", new PropertyMetadata() { label = "Purchase Order Unit", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"GrossWeight", new PropertyMetadata() { label = "Gross Weight", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"VolumeUnit", new PropertyMetadata() { label = "Volume Unit", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"WeightUnitInISO", new PropertyMetadata() { label = "Weight Unit ISO", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"StatusOfMaterial", new PropertyMetadata() { label = "Status of Material", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"WeightUnit", new PropertyMetadata() { label = "Weight Unit", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"DimensionUnitInISO", new PropertyMetadata() { label = "Dimension Unit ISO", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"PurchaseOrderUnitDescription", new PropertyMetadata() { label = "Unit of Measure", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"IndustrySector", new PropertyMetadata() { label = "Industry Sector", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"MaterialNumber", new PropertyMetadata() { label = "Material Number", creatable = "false", updatable = "false", filterable = "", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"Length", new PropertyMetadata() { label = "Length", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"OldMaterialNumber", new PropertyMetadata() { label = "Old Material Number", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"VolumeUnitDescription", new PropertyMetadata() { label = "Volume Unit", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"PurchaseOrderUnitInISO", new PropertyMetadata() { label = "Purchase Order Unit in ISO Code", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"DimensionUnitDescription", new PropertyMetadata() { label = "Dimension Unit", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"BaseUOMISO", new PropertyMetadata() { label = "Base Unit of Measure ISO", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"Height", new PropertyMetadata() { label = "Height", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"MaterialDivision", new PropertyMetadata() { label = "Material Divison", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"IssueUnit", new PropertyMetadata() { label = "Issue Unit", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}           		  
		};
		
        public static Dictionary<string, PropertyMetadata> SAPPropertyAttributes
        {
            get
            {
                return sapPropertyAttributes;
            }
        }
		
		public string GetPropertyLabel(string propertyName)
        {
            return SAPPropertyAttributes[propertyName].label;
        }
		

    }
    public partial class AlternativeUOM
    {
        static Dictionary<string, PropertyMetadata> sapPropertyAttributes = new Dictionary<string, PropertyMetadata>() { 
					{"EANCategory", new PropertyMetadata() { label = "Category of International Article Number (EAN)", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"UOMDescription", new PropertyMetadata() { label = "Alternate Unit Of Measure", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"AltUnitOfMeasure", new PropertyMetadata() { label = "Alternate unit of measure", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"EANUPC", new PropertyMetadata() { label = "International Article Number (EAN/UPC)", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"AltUnitOfMeasureInISO", new PropertyMetadata() { label = "Alternate unit of measure ISO", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"Numerator", new PropertyMetadata() { label = "Numerator", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"Denominator", new PropertyMetadata() { label = "Denominator", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"EANCategoryDescription", new PropertyMetadata() { label = "EAN Category", creatable = "false", updatable = "false", filterable = "false", visible_in_list = "", visible_in_detail = "", semantics = "" }}  ,
			          			{"MaterialNumber", new PropertyMetadata() { label = "", creatable = "false", updatable = "false", filterable = "", visible_in_list = "", visible_in_detail = "", semantics = "" }}           		  
		};
		
        public static Dictionary<string, PropertyMetadata> SAPPropertyAttributes
        {
            get
            {
                return sapPropertyAttributes;
            }
        }
		
		public string GetPropertyLabel(string propertyName)
        {
            return SAPPropertyAttributes[propertyName].label;
        }
		

    }

}