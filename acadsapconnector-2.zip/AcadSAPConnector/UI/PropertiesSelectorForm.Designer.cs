﻿namespace AcadSAPConnector
{
    partial class PropertiesSelectorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PropertiesSelectorForm));
            this._propsSelectorCtrl = new AcadSAPConnector.PropertiesSelectorCtrl();
            this.SuspendLayout();
            // 
            // _propsSelectorCtrl
            // 
            this._propsSelectorCtrl.Dock = System.Windows.Forms.DockStyle.Fill;
            this._propsSelectorCtrl.Location = new System.Drawing.Point(0, 0);
            this._propsSelectorCtrl.Name = "_propsSelectorCtrl";
            this._propsSelectorCtrl.Size = new System.Drawing.Size(311, 490);
            this._propsSelectorCtrl.TabIndex = 0;
            // 
            // PropertiesSelectorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(311, 490);
            this.Controls.Add(this._propsSelectorCtrl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PropertiesSelectorForm";
            this.Text = "Service Properties Selector";
            this.ResumeLayout(false);

        }

        #endregion

        private PropertiesSelectorCtrl _propsSelectorCtrl;
    }
}