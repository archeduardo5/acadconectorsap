﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;

namespace AcadSAPConnector
{
    public partial class FilterCtrl : UserControl
    {
        public FilterCtrl()
        {
            InitializeComponent();

            Enabled = false;

            _cbProps.SelectedIndex = 0;

            _cbMode.SelectedIndex = 0;

            _cbProps.Enabled = false;

            bRefresh.Enabled = false;
        }

        public new bool Enabled
        {
            get
            {               
                return _cbFilter.Enabled;
            }

            set
            {
                _tbValue.Enabled = value;

                _cbMode.Enabled = value;

                _cbFilter.Checked = value;
            }
        }

        public void LoadProperties(Type type)
        {
            _cbProps.Items.Clear();
           
            foreach (MemberInfo memberInfo in type.GetMembers())
            {
                if (memberInfo.DeclaringType == type)
                { 
                    if(memberInfo.MemberType == MemberTypes.Property)
                    {
                        _cbProps.Items.Add(memberInfo.Name);
                    }
                }
            }

            _cbProps.SelectedIndex = 0;
        }

        private void tbValue_TextChanged(object sender, EventArgs e)
        {
            bRefresh.Enabled = (_tbValue.Text.Length > 0);
        }

        private void cbFilter_CheckedChanged(object sender, EventArgs e)
        {
            Enabled = _cbFilter.Checked;

            if (!_cbFilter.Checked || (_tbValue.Text.Length > 0))
            {
                FilterModified(new FilterModifiedEventArgs(
                   _cbFilter.Checked,
                   _tbValue.Text,
                   (_cbMode.SelectedIndex == 0)));
            }   
        }

        ////////////////////////////////////////////////////////////////////////
        // 
        //
        ////////////////////////////////////////////////////////////////////////
        private void FilterModified(FilterModifiedEventArgs e)
        {
            if (FilterModifiedEvent != null)
                FilterModifiedEvent(this, e);
        }

        public event FilterModifiedHandler FilterModifiedEvent = null;

        private void bGo_Click(object sender, EventArgs e)
        {
            FilterModified(new FilterModifiedEventArgs(
               _cbFilter.Checked,
               _tbValue.Text,
               (_cbMode.SelectedIndex == 0)));
        }
    }

    ////////////////////////////////////////////////////////////////////////////
    // 
    //
    ////////////////////////////////////////////////////////////////////////////
    public class FilterModifiedEventArgs : EventArgs
    {
        public bool Enabled
        {
            private set;
            get;
        }

        public string Expression
        {
            private set;
            get;
        }

        public bool Contains
        {
            private set;
            get;
        }

        public FilterModifiedEventArgs(
            bool enabled, 
            string expression, 
            bool contains)
        {
            Enabled = enabled;
            Expression = expression;
            Contains = contains;
        }
    }

    public delegate void FilterModifiedHandler(
        object o,
        FilterModifiedEventArgs e);
}
